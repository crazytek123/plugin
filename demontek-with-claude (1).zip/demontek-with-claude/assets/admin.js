/* DEMONTEK Admin Styles */
.demontek-admin-wrap {
    background: #f1f1f1;
    margin: 0 -20px -30px;
    padding: 0;
}

.demontek-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 40px 30px;
    margin: 0 0 30px 0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
}

.demontek-header h1 {
    font-size: 2.5em;
    margin: 0 0 10px 0;
    font-weight: 700;
    text-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.demontek-header p {
    font-size: 1.2em;
    margin: 0;
    opacity: 0.9;
    font-weight: 300;
}

.demontek-container {
    display: grid;
    grid-template-columns: 1fr 400px;
    gap: 30px;
    padding: 0 30px;
    max-width: 1400px;
    margin: 0 auto;
}

/* Cards */
.demontek-card {
    background: white;
    border-radius: 12px;
    padding: 25px;
    margin-bottom: 20px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.08);
    border: 1px solid rgba(0,0,0,0.05);
    transition: all 0.3s ease;
}

.demontek-card:hover {
    box-shadow: 0 4px 25px rgba(0,0,0,0.12);
    transform: translateY(-2px);
}

.demontek-card h3 {
    font-size: 1.3em;
    margin: 0 0 20px 0;
    color: #2c3e50;
    font-weight: 600;
    border-bottom: 2px solid #ecf0f1;
    padding-bottom: 10px;
}

/* Toggle Switch */
.demontek-toggle-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
}

.demontek-toggle-card h3 {
    color: white;
    border-bottom-color: rgba(255,255,255,0.2);
}

.demontek-toggle {
    display: flex;
    align-items: center;
    gap: 15px;
    font-size: 1.1em;
    font-weight: 500;
}

.demontek-toggle input[type="checkbox"] {
    display: none;
}

.demontek-slider {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 30px;
    background: rgba(255,255,255,0.3);
    border-radius: 30px;
    transition: all 0.3s ease;
    cursor: pointer;
}

.demontek-slider:before {
    content: '';
    position: absolute;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    top: 2px;
    left: 2px;
    background: white;
    transition: all 0.3s ease;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
}

.demontek-toggle input:checked + .demontek-slider {
    background: rgba(255,255,255,0.9);
}

.demontek-toggle input:checked + .demontek-slider:before {
    transform: translateX(30px);
    background: #27ae60;
}

/* Custom Checkboxes */
.demontek-checkbox {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 0;
    cursor: pointer;
    transition: all 0.2s ease;
    border-radius: 8px;
    padding: 12px;
    margin: 4px 0;
}

.demontek-checkbox:hover {
    background: rgba(103, 126, 234, 0.05);
}

.demontek-checkbox input[type="checkbox"] {
    display: none;
}

.demontek-checkmark {
    width: 20px;
    height: 20px;
    border: 2px solid #ddd;
    border-radius: 4px;
    position: relative;
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.demontek-checkbox input:checked + .demontek-checkmark {
    background: #667eea;
    border-color: #667eea;
}

.demontek-checkbox input:checked + .demontek-checkmark:after {
    content: '✓';
    position: absolute;
    color: white;
    font-size: 14px;
    font-weight: bold;
    top: -2px;
    left: 3px;
}

/* Custom Radio Buttons */
.demontek-radio-group {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.demontek-radio {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    cursor: pointer;
    border-radius: 8px;
    transition: all 0.2s ease;
}

.demontek-radio:hover {
    background: rgba(103, 126, 234, 0.05);
}

.demontek-radio input[type="radio"] {
    display: none;
}

.demontek-radio-mark {
    width: 20px;
    height: 20px;
    border: 2px solid #ddd;
    border-radius: 50%;
    position: relative;
    transition: all 0.3s ease;
    flex-shrink: 0;
}

.demontek-radio input:checked + .demontek-radio-mark {
    border-color: #667eea;
    background: #667eea;
}

.demontek-radio input:checked + .demontek-radio-mark:after {
    content: '';
    position: absolute;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: white;
    top: 4px;
    left: 4px;
}

/* Form Elements */
.demontek-form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
}

.demontek-form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.demontek-form-group label {
    font-weight: 600;
    color: #2c3e50;
    font-size: 0.95em;
}

.demontek-select, .demontek-input {
    padding: 12px 16px;
    border: 2px solid #ecf0f1;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s ease;
    background: white;
}

.demontek-select:focus, .demontek-input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(103, 126, 234, 0.1);
}

/* Grids */
.demontek-grid-2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.demontek-grid-3 {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
}

/* Custom Field */
.demontek-custom-field {
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 15px;
    background: rgba(103, 126, 234, 0.05);
    border-radius: 8px;
    margin-top: 15px;
}

/* Save Button */
.demontek-save-section {
    text-align: center;
    padding: 30px 0;
    border-top: 2px solid #ecf0f1;
    margin-top: 30px;
}

.demontek-save-btn {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 15px 40px;
    border-radius: 50px;
    font-size: 1.1em;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(103, 126, 234, 0.3);
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0 auto;
}

.demontek-save-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(103, 126, 234, 0.4);
}

.demontek-save-btn:active {
    transform: translateY(0);
}

/* Sidebar */
.demontek-sidebar {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

/* Preview Card */
.demontek-preview-card {
    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
    color: white;
}

.demontek-preview-card h3 {
    color: white;
    border-bottom-color: rgba(255,255,255,0.2);
}

.demontek-mobile-frame {
    display: flex;
    justify-content: center;
    margin: 20px 0;
}

.demontek-mobile-screen {
    width: 200px;
    height: 300px;
    border: 4px solid #34495e;
    border-radius: 15px;
    position: relative;
    overflow: hidden;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.demontek-preview-title {
    position: absolute;
    top: 20px;
    left: 15px;
    background: rgba(0,0,0,0.85);
    color: white;
    padding: 10px 15px;
    border-radius: 8px;
    font-size: 12px;
    max-width: 150px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.2);
}

.demontek-preview-title .title-text {
    font-weight: bold;
    margin-bottom: 4px;
    line-height: 1.2;
}

.demontek-preview-title .title-meta {
    opacity: 0.8;
    font-size: 10px;
    line-height: 1.3;
}

.demontek-preview-content {
    position: absolute;
    top: 90px;
    left: 15px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    max-width: 160px;
}

.demontek-preview-excerpt {
    background: rgba(0,0,0,0.75);
    color: white;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 9px;
    line-height: 1.4;
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255,255,255,0.15);
}

.demontek-preview-slot {
    padding: 6px 10px;
    border-radius: 4px;
    font-size: 8px;
    font-weight: bold;
    text-align: center;
    display: none;
}

.demontek-trailer { background: rgba(255,20,60,0.8); color: white; }
.demontek-review { background: rgba(255,193,7,0.9); color: #333; }
.demontek-price { background: rgba(40,167,69,0.9); color: white; }
.demontek-custom { background: rgba(102,126,234,0.8); color: white; }

.demontek-preview-nav {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 8px;
}

.preview-btn {
    width: 30px;
    height: 30px;
    background: rgba(255,255,255,0.95);
    color: #333;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: bold;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    cursor: pointer;
    transition: all 0.2s ease;
}

.preview-btn.delete-btn {
    background: rgba(220,53,69,0.95);
    color: white;
}

.preview-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

/* Presets */
.demontek-presets {
    display: flex;
    gap: 8px;
    margin-top: 15px;
}

.demontek-preset-btn {
    flex: 1;
    padding: 8px 12px;
    background: rgba(255,255,255,0.1);
    color: white;
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 6px;
    font-size: 11px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.demontek-preset-btn:hover {
    background: rgba(255,255,255,0.2);
}

/* Guide Card */
.demontek-guide-card {
    background: #f8f9fa;
    border: 2px solid #e9ecef;
}

.demontek-guide-section {
    margin-bottom: 20px;
}

.demontek-guide-section h4 {
    font-size: 1.1em;
    margin: 0 0 12px 0;
    color: #2c3e50;
    font-weight: 600;
}

.demontek-field-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.demontek-field-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 8px 12px;
    background: white;
    border-radius: 6px;
    border: 1px solid #e9ecef;
}

.demontek-field-item code {
    background: #667eea;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.85em;
    font-weight: 600;
    min-width: 100px;
    text-align: center;
}

.demontek-field-item span {
    font-size: 0.9em;
    color: #6c757d;
}

.demontek-troubleshoot-list, .demontek-mobile-info {
    font-size: 0.9em;
    line-height: 1.6;
    color: #6c757d;
    margin: 0;
    padding-left: 20px;
}

.demontek-troubleshoot-list li, .demontek-mobile-info li {
    margin-bottom: 6px;
}

/* Messages */
#demontek-messages {
    position: fixed;
    top: 32px;
    right: 20px;
    z-index: 99999;
    max-width: 400px;
}

#demontek-messages .notice {
    margin: 0 0 10px 0;
    border-left-width: 4px;
    border-radius: 0 6px 6px 0;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

/* Responsive */
@media (max-width: 1200px) {
    .demontek-container {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .demontek-form-row {
        grid-template-columns: 1fr;
    }
    
    .demontek-grid-3 {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .demontek-header {
        padding: 20px 15px;
    }
    
    .demontek-header h1 {
        font-size: 2em;
    }
    
    .demontek-container {
        padding: 0 15px;
    }
    
    .demontek-card {
        padding: 20px;
    }
    
    .demontek-grid-2 {
        grid-template-columns: 1fr;
    }
}