jQuery(document).ready(function($) {
    console.log('🚀 DEMONTEK: Frontend script loading...');
    
    // Get data passed from PHP
    var settings = demontekData.settings;
    var postData = demontekData;
    
    console.log('📊 Settings:', settings);
    console.log('📄 Post Data:', postData);
    
    if (!settings.enabled) {
        console.log('❌ DEMONTEK: Plugin disabled');
        return;
    }
    
    // Hide original titles immediately if needed
    if (settings.hide_original_title) {
        hideOriginalTitles();
    }
    
    // Wait for load delay, then inject content
    setTimeout(function() {
        injectContent();
    }, parseInt(settings.load_delay || 500));
    
    /**
     * Hide original titles
     */
    function hideOriginalTitles() {
        console.log('🙈 Hiding original titles');
        
        var hideCSS = '<style id="demontek-hide-titles">';
        hideCSS += '.nectar-post-title, .entry-title, .post-title, h1.entry-title, ';
        hideCSS += '.page-header-title, .single-title, .page-title, .post-header h1, ';
        hideCSS += '.article-title, .content-title, .main-title, .hero-title, ';
        hideCSS += '.featured-title, .banner-title, .header-title, .single-post-title, ';
        hideCSS += '.blog-title, .article-header h1, .content-header h1 { ';
        hideCSS += 'display: none !important; visibility: hidden !important; ';
        hideCSS += 'opacity: 0 !important; height: 0 !important; ';
        hideCSS += 'margin: 0 !important; padding: 0 !important; ';
        hideCSS += 'position: absolute !important; left: -9999px !important; }';
        hideCSS += '</style>';
        
        $('head').prepend(hideCSS);
    }
    
    /**
     * Main content injection
     */
    function injectContent() {
        console.log('💉 Starting content injection...');
        
        // Find container
        var container = findContainer();
        if (!container.length) {
            console.error('❌ No suitable container found');
            return;
        }
        
        console.log('📦 Using container:', container.prop('tagName'), container.attr('id') || container.attr('class'));
        
        // Build content
        var allContent = '';
        
        // Add title block
        if (settings.title_position && settings.title_position !== 'disabled') {
            allContent += buildTitleBlock();
        }
        
        // Add content slots
        if (settings.title_position !== 'disabled') {
            allContent += buildContentSlots();
        }
        
        // Add navigation
        allContent += buildNavigation();
        
        // Inject content
        if (allContent) {
            container.append(allContent);
            console.log('✅ Content injected successfully');
            
            // Apply mobile styles
            applyMobileStyles();
            
            // Bind events
            bindEvents();
        } else {
            console.log('⚠️ No content to inject');
        }
    }
    
    /**
     * Find suitable container
     */
    function findContainer() {
        var containers = [
            '#page-header-bg',
            '.page-header-bg-image',
            '.nectar-slider-wrap',
            'header',
            '.page-header',
            '.single-post',
            'body'
        ];
        
        for (var i = 0; i < containers.length; i++) {
            var container = $(containers[i]).first();
            if (container.length) {
                console.log('📍 Found container:', containers[i]);
                return container;
            }
        }
        
        console.log('📍 Using body as fallback');
        return $('body');
    }
    
    /**
     * Build title block
     */
    function buildTitleBlock() {
        console.log('📝 Building title block');
        
        var titleCSS = getTitleCSS(settings.title_position);
        var titleContent = '<div class="title-text" style="font-size: 24px; font-weight: bold; margin-bottom: 8px; color: #fff; line-height: 1.2;">' + 
            postData.postTitle + '</div>';
        
        if (!settings.hide_meta_info) {
            titleContent += '<div class="title-meta" style="font-size: 14px; color: #ccc; line-height: 1.3;">By <strong style="color: #fff;">' + 
                postData.postAuthor + '</strong> • ' + postData.postDate + ' • Gaming</div>';
        }
        
        return '<div class="demontek-title-block" style="' + titleCSS + '">' + titleContent + '</div>';
    }
    
    /**
     * Build content slots
     */
    function buildContentSlots() {
        console.log('📋 Building content slots');
        
        var contentSlots = [];
        
        // Excerpt
        if (settings.show_excerpt && postData.postExcerpt) {
            contentSlots.push(buildExcerptSlot());
        }
        
        // Trailers
        if (settings.show_trailers && postData.customFields.trailer_url) {
            contentSlots.push(buildTrailerSlot());
        }
        
        // Reviews
        if (settings.show_reviews && postData.customFields.review_score) {
            contentSlots.push(buildReviewSlot());
        }
        
        // Price
        if (settings.show_price && postData.customFields.game_price) {
            contentSlots.push(buildPriceSlot());
        }
        
        // Custom field
        if (settings.show_custom_field && postData.customFields.custom_field) {
            contentSlots.push(buildCustomSlot());
        }
        
        if (contentSlots.length > 0) {
            var contentCSS = getContentSlotsCSS(settings.title_position, settings.content_layout);
            return '<div class="demontek-content-slots" style="' + contentCSS + '">' + contentSlots.join('') + '</div>';
        }
        
        return '';
    }
    
    /**
     * Build individual content slots
     */
    function buildExcerptSlot() {
        return '<div class="demontek-excerpt" style="background: rgba(0,0,0,0.75); color: white; padding: 12px 16px; border-radius: 8px; font-size: 14px; line-height: 1.4; backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.15); margin-bottom: 8px;">' + 
            postData.postExcerpt + '</div>';
    }
    
    function buildTrailerSlot() {
        return '<div class="demontek-trailer" style="background: rgba(255,20,60,0.9); color: white; padding: 8px 12px; border-radius: 6px; font-size: 12px; font-weight: bold; margin-bottom: 8px; text-align: center;">🎬 TRAILER AVAILABLE</div>';
    }
    
    function buildReviewSlot() {
        var reviewText = '⭐ ' + postData.customFields.review_score + '/5';
        if (postData.customFields.review_source) {
            reviewText += ' - ' + postData.customFields.review_source;
        }
        return '<div class="demontek-review" style="background: rgba(255,193,7,0.9); color: #333; padding: 8px 12px; border-radius: 6px; font-size: 12px; font-weight: bold; margin-bottom: 8px; text-align: center;">' + 
            reviewText + '</div>';
    }
    
    function buildPriceSlot() {
        return '<div class="demontek-price" style="background: rgba(40,167,69,0.9); color: white; padding: 8px 12px; border-radius: 6px; font-size: 12px; font-weight: bold; margin-bottom: 8px; text-align: center;">💰 $' + 
            postData.customFields.game_price + '</div>';
    }
    
    function buildCustomSlot() {
        return '<div class="demontek-custom" style="background: rgba(102,126,234,0.85); color: white; padding: 8px 12px; border-radius: 6px; font-size: 12px; font-weight: bold; margin-bottom: 8px; text-align: center;">🎮 ' + 
            postData.customFields.custom_field + '</div>';
    }
    
    /**
     * Build navigation
     */
    function buildNavigation() {
        console.log('🎯 Building navigation');
        
        var navButtons = [];
        
        // Previous button
        if (settings.show_prev && postData.prevPost) {
            navButtons.push('<a href="' + postData.prevPost.url + '" style="' + getButtonCSS(false) + '" title="' + postData.prevPost.title + '">‹</a>');
        }
        
        // Next button
        if (settings.show_next && postData.nextPost) {
            navButtons.push('<a href="' + postData.nextPost.url + '" style="' + getButtonCSS(false) + '" title="' + postData.nextPost.title + '">›</a>');
        }
        
        // Delete button
        if (settings.show_delete && postData.canDeletePost) {
            navButtons.push('<button class="demontek-delete" data-post="' + postData.postId + '" style="' + getButtonCSS(true) + '" title="Delete Post">🗑</button>');
        }
        
        if (navButtons.length > 0) {
            var navCSS = getNavCSS(settings.position);
            return '<div class="demontek-navigation" style="' + navCSS + '">' + navButtons.join('') + '</div>';
        }
        
        return '';
    }
    
    /**
     * CSS generation functions
     */
    function getTitleCSS(pos) {
        var base = 'position: absolute !important; z-index: 9998 !important; background: rgba(0,0,0,0.85) !important; color: white !important; padding: 20px !important; border-radius: 12px !important; backdrop-filter: blur(15px) !important; border: 1px solid rgba(255,255,255,0.2) !important; box-shadow: 0 8px 32px rgba(0,0,0,0.4) !important; ';
        
        switch(pos) {
            case 'top-left': 
                return base + 'top: 30px !important; left: 30px !important; max-width: 400px !important;';
            case 'top-center': 
                return base + 'top: 30px !important; left: 50% !important; transform: translateX(-50%) !important; max-width: 400px !important;';
            case 'top-right': 
                return base + 'top: 30px !important; right: 30px !important; left: auto !important; max-width: 400px !important;';
            case 'bottom-left': 
                return base + 'bottom: 120px !important; left: 30px !important; top: auto !important; max-width: 400px !important;';
            default: 
                return base + 'top: 30px !important; left: 30px !important; max-width: 400px !important;';
        }
    }
    
    function getContentSlotsCSS(titlePos, layout) {
        var base = 'position: absolute !important; z-index: 9997 !important; ';
        var flexDirection = layout === 'side-by-side' ? 'row' : 'column';
        var gap = layout === 'side-by-side' ? '8px' : '0px';
        
        base += 'display: flex !important; flex-direction: ' + flexDirection + ' !important; gap: ' + gap + ' !important; flex-wrap: wrap !important; max-width: 400px !important; ';
        
        // FIXED: Better spacing to avoid title overlap
        switch(titlePos) {
            case 'top-left': 
                return base + 'top: 140px !important; left: 30px !important;';
            case 'top-center': 
                return base + 'top: 140px !important; left: 50% !important; transform: translateX(-50%) !important;';
            case 'top-right': 
                return base + 'top: 140px !important; right: 30px !important; left: auto !important;';
            case 'bottom-left': 
                return base + 'bottom: 240px !important; left: 30px !important; top: auto !important;';
            default: 
                return base + 'top: 140px !important; left: 30px !important;';
        }
    }
    
    function getNavCSS(pos) {
        var base = 'position: absolute !important; z-index: 9999 !important; display: flex !important; gap: 15px !important; ';
        
        switch(pos) {
            case 'bottom-center': 
                return base + 'bottom: 30px !important; left: 50% !important; transform: translateX(-50%) !important;';
            case 'bottom-left': 
                return base + 'bottom: 30px !important; left: 30px !important;';
            case 'bottom-right': 
                return base + 'bottom: 30px !important; right: 30px !important;';
            case 'top-center': 
                return base + 'top: 30px !important; left: 50% !important; transform: translateX(-50%) !important;';
            case 'top-left': 
                return base + 'top: 30px !important; left: 30px !important;';
            case 'top-right': 
                return base + 'top: 30px !important; right: 30px !important;';
            default: 
                return base + 'bottom: 30px !important; left: 50% !important; transform: translateX(-50%) !important;';
        }
    }
    
    function getButtonCSS(isDelete) {
        var base = 'display: inline-flex !important; align-items: center !important; justify-content: center !important; text-decoration: none !important; font-weight: 600 !important; cursor: pointer !important; transition: all 0.3s ease !important; backdrop-filter: blur(10px) !important; box-shadow: 0 4px 15px rgba(0,0,0,0.2) !important; border: none !important; ';
        
        var bgColor = isDelete ? 'rgba(220,53,69,0.95)' : (settings.dark_mode ? 'rgba(50,50,50,0.95)' : 'rgba(255,255,255,0.95)');
        var textColor = isDelete ? '#fff' : (settings.dark_mode ? '#fff' : '#333');
        
        base += 'background: ' + bgColor + ' !important; color: ' + textColor + ' !important; ';
        
        switch(settings.button_style) {
            case 'circular':
                return base + 'width: 55px !important; height: 55px !important; border-radius: 50% !important; font-size: 20px !important;';
            case 'pill':
                return base + 'padding: 14px 28px !important; border-radius: 30px !important; font-size: 16px !important; white-space: nowrap !important;';
            case 'square':
                return base + 'width: 55px !important; height: 55px !important; border-radius: 8px !important; font-size: 20px !important;';
            default:
                return base + 'width: 55px !important; height: 55px !important; border-radius: 50% !important; font-size: 20px !important;';
        }
    }
    
    /**
     * Apply mobile styles and fix responsive image
     */
    function applyMobileStyles() {
        var mobileCSS = '<style id="demontek-mobile-styles">';
        
        // FIXED: Prevent header image from shrinking
        mobileCSS += '#page-header-bg { min-height: 350px !important; background-size: cover !important; background-position: center !important; }';
        
        // Mobile positioning
        mobileCSS += '@media (max-width: 690px) {';
        mobileCSS += '#page-header-bg { min-height: 400px !important; padding-top: 200px !important; padding-bottom: 200px !important; }';
        mobileCSS += '.demontek-title-block { top: 220px !important; left: 15px !important; right: 15px !important; max-width: none !important; transform: none !important; }';
        mobileCSS += '.demontek-content-slots { top: 340px !important; left: 15px !important; right: 15px !important; max-width: none !important; transform: none !important; }';
        mobileCSS += '.demontek-navigation { bottom: 30px !important; left: 50% !important; transform: translateX(-50%) !important; }';
        mobileCSS += '.demontek-title-block[style*="bottom"] { bottom: 240px !important; top: auto !important; }';
        mobileCSS += '.demontek-content-slots[style*="bottom"] { bottom: 360px !important; top: auto !important; }';
        mobileCSS += '}';
        
        // Desktop spacing fix
        mobileCSS += '@media (min-width: 691px) {';
        mobileCSS += '.demontek-content-slots { top: 140px !important; }';
        mobileCSS += '.demontek-content-slots[style*="bottom"] { bottom: 240px !important; }';
        mobileCSS += '}';
        
        mobileCSS += '</style>';
        $('head').append(mobileCSS);
        console.log('📱 Mobile styles and responsive fixes applied');
    }
    
    /**
     * Bind events
     */
    function bindEvents() {
        // Delete functionality
        $('.demontek-delete').on('click', function() {
            if (confirm('Delete this post? This cannot be undone.')) {
                var postId = $(this).data('post');
                $(this).text('⚠').prop('disabled', true);
                
                $.post(postData.ajaxUrl, {
                    action: 'demontek_delete_post',
                    post_id: postId,
                    nonce: postData.deleteNonce
                }, function(response) {
                    if (response.success) {
                        if (postData.nextPost) {
                            window.location.href = postData.nextPost.url;
                        } else if (postData.prevPost) {
                            window.location.href = postData.prevPost.url;
                        } else {
                            window.location.href = '/';
                        }
                    } else {
                        alert('Error: ' + response.data);
                        location.reload();
                    }
                });
            }
        });
    }
});