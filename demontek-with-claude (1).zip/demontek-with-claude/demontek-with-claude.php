<?php
/**
 * Plugin Name: DEMONTEK Content Manager
 * Description: Advanced navigation and content management system for DEMONTEK
 * Version: 4.2.0
 * Author: DEMONTEK Team
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('DEMONTEK_VERSION', '4.2.0');
define('DEMONTEK_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DEMONTEK_PLUGIN_PATH', plugin_dir_path(__FILE__));

/**
 * Main DEMONTEK Plugin Class
 */
class DemontekManager {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'frontend_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_demontek_delete_post', array($this, 'ajax_delete_post'));
        add_action('wp_ajax_demontek_save_settings', array($this, 'ajax_save_settings'));
        add_action('wp_ajax_demontek_get_preview_posts', array($this, 'ajax_get_preview_posts'));
        
        // Frontend injection
        if (get_option('demontek_enabled', true)) {
            add_action('wp_footer', array($this, 'inject_navigation'));
        }
    }
    
    public function init() {
        // Initialize default settings
        if (get_option('demontek_settings') === false) {
            $this->set_default_settings();
        }
    }
    
    /**
     * Set default plugin settings
     */
    private function set_default_settings() {
        $defaults = array(
            'enabled' => true,
            'show_prev' => true,
            'show_next' => true,
            'show_delete' => true,
            'button_style' => 'circular',
            'position' => 'bottom-center',
            'dark_mode' => false,
            'show_on_mobile' => true,
            'delete_redirect' => 'smart',
            'load_delay' => 500,
            'enable_debug' => false,
            'title_position' => 'top-left',
            'show_excerpt' => true,
            'hide_original_title' => false,
            'show_trailers' => false,
            'show_reviews' => false,
            'show_price' => false,
            'show_custom_field' => false,
            'custom_field_name' => '',
            'content_layout' => 'stacked'
        );
        
        update_option('demontek_settings', $defaults);
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_options_page(
            'DEMONTEK Manager',
            'DEMONTEK Manager',
            'manage_options',
            'demontek-manager',
            array($this, 'admin_page')
        );
    }
    
    /**
     * Admin page HTML - load from separate file
     */
    public function admin_page() {
        include_once DEMONTEK_PLUGIN_PATH . 'includes/admin-page.php';
    }
    
    /**
     * Enqueue admin scripts
     */
    public function admin_scripts($hook) {
        if ($hook === 'settings_page_demontek-manager') {
            wp_enqueue_script('jquery');
            
            // Enqueue admin CSS
            wp_enqueue_style(
                'demontek-admin',
                DEMONTEK_PLUGIN_URL . 'assets/admin.css',
                array(),
                DEMONTEK_VERSION
            );
            
            // Enqueue admin JS
            wp_enqueue_script(
                'demontek-admin',
                DEMONTEK_PLUGIN_URL . 'assets/admin.js',
                array('jquery'),
                DEMONTEK_VERSION,
                true
            );
            
            // Pass data to admin script
            wp_localize_script('demontek-admin', 'demontekAdmin', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'settingsNonce' => wp_create_nonce('demontek_settings_nonce'),
                'previewNonce' => wp_create_nonce('demontek_preview_nonce')
            ));
        }
    }
    
    /**
     * Enqueue frontend scripts
     */
    public function frontend_scripts() {
        if (is_single() && get_option('demontek_enabled', true)) {
            wp_enqueue_script('jquery');
            wp_enqueue_script(
                'demontek-frontend',
                DEMONTEK_PLUGIN_URL . 'assets/frontend.js',
                array('jquery'),
                DEMONTEK_VERSION,
                true
            );
            
            // Pass data to frontend
            wp_localize_script('demontek-frontend', 'demontekData', array(
                'settings' => get_option('demontek_settings', array()),
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'deleteNonce' => wp_create_nonce('demontek_delete_nonce'),
                'postId' => get_the_ID(),
                'postTitle' => get_the_title(),
                'postAuthor' => get_the_author(),
                'postDate' => get_the_date('F j, Y'),
                'postExcerpt' => wp_trim_words(get_the_excerpt() ?: get_the_content(), 20),
                'prevPost' => $this->get_prev_post_data(),
                'nextPost' => $this->get_next_post_data(),
                'canDeletePost' => current_user_can('delete_post', get_the_ID()),
                'customFields' => $this->get_custom_fields_data()
            ));
        }
    }
    
    /**
     * Get previous post data
     */
    private function get_prev_post_data() {
        $prev_post = get_previous_post();
        if ($prev_post) {
            return array(
                'id' => $prev_post->ID,
                'title' => get_the_title($prev_post->ID),
                'url' => get_permalink($prev_post->ID)
            );
        }
        return null;
    }
    
    /**
     * Get next post data
     */
    private function get_next_post_data() {
        $next_post = get_next_post();
        if ($next_post) {
            return array(
                'id' => $next_post->ID,
                'title' => get_the_title($next_post->ID),
                'url' => get_permalink($next_post->ID)
            );
        }
        return null;
    }
    
    /**
     * Get custom fields data
     */
    private function get_custom_fields_data() {
        $post_id = get_the_ID();
        $settings = get_option('demontek_settings', array());
        
        return array(
            'trailer_url' => get_post_meta($post_id, 'trailer_url', true),
            'review_score' => get_post_meta($post_id, 'review_score', true),
            'review_source' => get_post_meta($post_id, 'review_source', true),
            'game_price' => get_post_meta($post_id, 'game_price', true),
            'custom_field' => !empty($settings['custom_field_name']) ? 
                get_post_meta($post_id, $settings['custom_field_name'], true) : ''
        );
    }
    
    /**
     * AJAX save settings
     */
    public function ajax_save_settings() {
        include_once DEMONTEK_PLUGIN_PATH . 'includes/ajax-handlers.php';
        demontek_save_settings();
    }
    
    /**
     * AJAX get preview posts
     */
    public function ajax_get_preview_posts() {
        include_once DEMONTEK_PLUGIN_PATH . 'includes/ajax-handlers.php';
        demontek_get_preview_posts();
    }
    
    /**
     * AJAX delete post
     */
    public function ajax_delete_post() {
        include_once DEMONTEK_PLUGIN_PATH . 'includes/ajax-handlers.php';
        demontek_delete_post();
    }
    
    /**
     * Inject navigation on frontend - simplified
     */
    public function inject_navigation() {
        if (!is_single()) return;
        
        $settings = get_option('demontek_settings', array());
        if (!($settings['enabled'] ?? true)) return;
        
        // Just add debug indicator and basic CSS
        echo '<!-- DEMONTEK: Plugin Active -->';
        echo '<div style="position: fixed; top: 10px; right: 10px; background: red; color: white; padding: 5px; z-index: 99999; font-size: 10px;">DEMONTEK ACTIVE</div>';
        
        // Include CSS
        include_once DEMONTEK_PLUGIN_PATH . 'includes/frontend-css.php';
    }
}

// Initialize the plugin
new DemontekManager();

/**
 * Plugin activation hook
 */
register_activation_hook(__FILE__, function() {
    $defaults = array(
        'enabled' => true,
        'show_prev' => true,
        'show_next' => true,
        'show_delete' => true,
        'button_style' => 'circular',
        'position' => 'bottom-center',
        'dark_mode' => false,
        'show_on_mobile' => true,
        'delete_redirect' => 'smart',
        'load_delay' => 500,
        'enable_debug' => false,
        'title_position' => 'top-left',
        'show_excerpt' => true,
        'hide_original_title' => false,
        'hide_meta_info' => false,
        'mobile_template' => 'edge-to-edge',
        'title_background' => 'solid',
        'show_trailers' => false,
        'show_reviews' => false,
        'show_price' => false,
        'show_custom_field' => false,
        'custom_field_name' => '',
        'content_layout' => 'stacked'
    );
    
    update_option('demontek_settings', $defaults);
});

/**
 * Plugin deactivation hook
 */
register_deactivation_hook(__FILE__, function() {
    // Clean up if needed
});

?>