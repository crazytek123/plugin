<!-- Right Panel: Live Preview -->
        <div style="flex: 0 0 300px; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h2 style="margin-top: 0; color: #2271b1;">📱 Live Preview</h2>
            
            <!-- Mobile Frame -->
            <div id="mobile-preview" style="width: 200px; height: 300px; border: 4px solid #333; border-radius: 15px; position: relative; overflow: hidden; margin: 0 auto 20px; background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiM2NjdlZWE7c3RvcC1vcGFjaXR5OjEiIC8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojNzY0YmEyO3N0b3Atb3BhY2l0eToxIiAvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZykiIC8+PC9zdmc+'); background-size: cover; background-position: center 20%;">
                
                <!-- Sample Title -->
                <div id="preview-title" style="position: absolute; top: 20px; left: 15px; background: rgba(0,0,0,0.85); color: white; padding: 10px 15px; border-radius: 8px; font-size: 12px; max-width: 150px; backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.2);">
                    <div class="title-text" style="font-weight: bold; margin-bottom: 4px; line-height: 1.2;">Sample Gaming Post</div>
                    <div class="title-meta" style="opacity: 0.8; font-size: 10px; line-height: 1.3;">by Author • Gaming</div>
                </div>
                
                <!-- Sample Content Slots Container -->
                <div id="preview-content-slots" style="position: absolute; top: 90px; left: 15px; display: flex; flex-direction: column; gap: 8px; max-width: 160px;">
                    
                    <!-- Sample Excerpt -->
                    <div id="preview-excerpt" style="background: rgba(0,0,0,0.75); color: white; padding: 8px 12px; border-radius: 6px; font-size: 9px; line-height: 1.4; backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.15);">
                        This is a sample excerpt showing how your content will look...
                    </div>
                    
                    <!-- Sample Trailer -->
                    <div id="preview-trailer" style="background: rgba(255,20,60,0.8); color: white; padding: 6px 10px; border-radius: 4px; font-size: 8px; font-weight: bold; display: none;">
                        🎬 TRAILER AVAILABLE
                    </div>
                    
                    <!-- Sample Review -->
                    <div id="preview-review" style="background: rgba(255,193,7,0.9); color: #333; padding: 6px 10px; border-radius: 4px; font-size: 8px; font-weight: bold; display: none;">
                        ⭐ 4.5/5 - IGN Review
                    </div>
                    
                    <!-- Sample Price -->
                    <div id="preview-price" style="background: rgba(40,167,69,0.9); color: white; padding: 6px 10px; border-radius: 4px; font-size: 8px; font-weight: bold; display: none;">
                        💰 $59.99
                    </div>
                    
                    <!-- Sample Custom Field -->
                    <div id="preview-custom" style="background: rgba(102,126,234,0.8); color: white; padding: 6px 10px; border-radius: 4px; font-size: 8px; font-weight: bold; display: none;">
                        🎮 Custom Field
                    </div>
                    
                </div>
                
                <!-- Preview Buttons -->
                <div id="preview-buttons" style="position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); display: flex; gap: 8px;">
                    <div class="preview-btn prev-btn" style="width: 30px; height: 30px; background: rgba(255,255,255,0.95); color: #333; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; box-shadow: 0 2px 8px rgba(0,0,0,0.2); cursor: pointer; transition: all 0.2s ease;">‹</div>
                    <div class="preview-btn next-btn" style="width: 30px; height: 30px; background: rgba(255,255,255,0.95); color: #333; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; box-shadow: 0 2px 8px rgba(0,0,0,0.2); cursor: pointer; transition: all 0.2s ease;">›</div>
                    <div class="preview-btn delete-btn" style="width: 30px; height: 30px; background: rgba(220,53,69,0.95); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: bold; box-shadow: 0 2px 8px rgba(0,0,0,0.2); cursor: pointer; transition: all 0.2s ease;">🗑</div>
                </div>
                
            </div>
            
            <!-- Setup Guide -->
            <div style="margin-bottom: 20px;">
                <h4>🎯 Custom Fields</h4>
                <p style="font-size: 13px; margin-bottom: 15px;">Add these custom fields to your posts:</p>
                <ul style="font-size: 12px; line-height: 1.4;">
                    <li><code>trailer_url</code> - Video trailer link</li>
                    <li><code>review_score</code> - Rating (e.g. "4.5")</li>
                    <li><code>review_source</code> - Review site (e.g. "IGN")</li>
                    <li><code>game_price</code> - Price without $ (e.g. "59.99")</li>
                </ul>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h4>🔧 Troubleshooting</h4>
                <p style="font-size: 13px;">If not working:</p>
                <ol style="font-size: 12px; line-height: 1.4;">
                    <li>Enable plugin above</li>
                    <li>Go to a single post page</li>
                    <li>Check browser console (F12)</li>
                    <li>Look for red "DEMONTEK ACTIVE" box</li>
                </ol>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h4>📱 Mobile Layout</h4>
                <p style="font-size: 13px;">Mobile positioning (≤690px):</p>
                <ul style="font-size: 12px; line-height: 1.4;">
                    <li>Title: 220px from top</li>
                    <li>Content: 340px from top</li>
                    <li>Full-width with 15px margins</li>
                    <li>Header image won't shrink</li>
                </ul>
            </div>
            
            <!-- Quick Actions -->
            <div style="display: grid; gap: 10px;">
                <button class="button" onclick="resetToDefaults()" style="width: 100%;">🔄 Reset to Defaults</button>
                <button class="button" onclick="applyGamingPreset()" style="width: 100%;">🎮 Gaming Preset</button>
                <button class="button" onclick="applyMinimalPreset()" style="width: 100%;">✨ Minimal Preset</button>
            </div>
        </div>
        
    </div>
    
    <!-- Status Messages -->
    <div id="demontek-messages" style="margin-top: 20px;"></div>
</div>

<style>
#demontek-admin input[type="checkbox"], #demontek-admin input[type="radio"] {
    transform: scale(1.1);
}
#demontek-admin h3 {
    color: #2271b1;
    border-bottom: 2px solid #f0f0f1;
    padding-bottom: 5px;
    margin-bottom: 15px;
}
#demontek-admin .button-primary {
    background: linear-gradient(45deg, #2271b1, #135e96) !important;
    border: none !important;
    text-shadow: none !important;
    box-shadow: 0 4px 15px rgba(34, 113, 177, 0.3) !important;
}
#demontek-admin .button-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 20px rgba(34, 113, 177, 0.4) !important;
}
.preview-btn.disabled {
    opacity: 0.5;
    cursor: not-allowed;
}
</style><?php
/**
 * Admin Page Template
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('demontek_settings', array());
?>

<div class="wrap">
    <h1>🚀 DEMONTEK CONTENT MANAGER</h1>
    <p>Advanced navigation and content management system</p>
    
    <div id="demontek-admin" style="display: flex; gap: 30px; margin-top: 20px;">
        
        <!-- Left Panel: Settings -->
        <div style="flex: 1; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h2 style="margin-top: 0; color: #2271b1;">⚙️ Global Settings</h2>
            
            <form id="demontek-settings-form">
                
                <!-- Main Toggle -->
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <label style="display: flex; align-items: center; font-weight: bold;">
                        <input type="checkbox" id="demontek_enabled" <?php checked($settings['enabled'] ?? true); ?> style="margin-right: 10px;">
                        Enable DEMONTEK Manager Site-Wide
                    </label>
                </div>
                
                <!-- Navigation Buttons -->
                <h3>🎯 Navigation Buttons</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="show_prev" <?php checked($settings['show_prev'] ?? true); ?> style="margin-right: 8px;">
                        Show Previous
                    </label>
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="show_next" <?php checked($settings['show_next'] ?? true); ?> style="margin-right: 8px;">
                        Show Next
                    </label>
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="show_delete" <?php checked($settings['show_delete'] ?? true); ?> style="margin-right: 8px;">
                        Show Delete
                    </label>
                </div>
                
                <!-- Title & Content -->
                <h3>📝 Title & Content Layout</h3>
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 10px;">Title Position:</label>
                    <select id="title_position" style="width: 100%; padding: 8px; margin-bottom: 15px;">
                        <option value="disabled" <?php selected($settings['title_position'] ?? 'top-left', 'disabled'); ?>>Disabled</option>
                        <option value="top-left" <?php selected($settings['title_position'] ?? 'top-left', 'top-left'); ?>>Top Left</option>
                        <option value="top-center" <?php selected($settings['title_position'] ?? 'top-left', 'top-center'); ?>>Top Center</option>
                        <option value="top-right" <?php selected($settings['title_position'] ?? 'top-left', 'top-right'); ?>>Top Right</option>
                        <option value="bottom-left" <?php selected($settings['title_position'] ?? 'top-left', 'bottom-left'); ?>>Bottom Left</option>
                    </select>
                    
                    <label style="display: block; margin-bottom: 10px;">Content Layout:</label>
                    <select id="content_layout" style="width: 100%; padding: 8px; margin-bottom: 15px;">
                        <option value="stacked" <?php selected($settings['content_layout'] ?? 'stacked', 'stacked'); ?>>Stacked (Vertical)</option>
                        <option value="side-by-side" <?php selected($settings['content_layout'] ?? 'stacked', 'side-by-side'); ?>>Side by Side</option>
                    </select>
                    
                    <label style="display: flex; align-items: center; margin-bottom: 10px;">
                        <input type="checkbox" id="hide_original_title" <?php checked($settings['hide_original_title'] ?? false); ?> style="margin-right: 8px;">
                        Hide Original Title
                    </label>
                </div>
                
                <!-- Content Slots -->
                <h3>📋 Content Slots</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="show_excerpt" <?php checked($settings['show_excerpt'] ?? true); ?> style="margin-right: 8px;">
                        Show Excerpt
                    </label>
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="show_trailers" <?php checked($settings['show_trailers'] ?? false); ?> style="margin-right: 8px;">
                        Show Trailers
                    </label>
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="show_reviews" <?php checked($settings['show_reviews'] ?? false); ?> style="margin-right: 8px;">
                        Show Reviews
                    </label>
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="show_price" <?php checked($settings['show_price'] ?? false); ?> style="margin-right: 8px;">
                        Show Price
                    </label>
                </div>
                
                <!-- Custom Field -->
                <div style="margin-bottom: 20px;">
                    <label style="display: flex; align-items: center; margin-bottom: 10px;">
                        <input type="checkbox" id="show_custom_field" <?php checked($settings['show_custom_field'] ?? false); ?> style="margin-right: 8px;">
                        Show Custom Field
                    </label>
                    <input type="text" id="custom_field_name" placeholder="Custom field name (e.g. 'game_rating')" value="<?php echo esc_attr($settings['custom_field_name'] ?? ''); ?>" style="width: 100%; padding: 8px;">
                </div>
                
                <!-- Button Style -->
                <h3>🎨 Button Style</h3>
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 10px;">
                        <input type="radio" name="button_style" value="circular" <?php checked($settings['button_style'] ?? 'circular', 'circular'); ?> style="margin-right: 8px;">
                        Circular
                    </label>
                    <label style="display: block; margin-bottom: 10px;">
                        <input type="radio" name="button_style" value="pill" <?php checked($settings['button_style'] ?? 'circular', 'pill'); ?> style="margin-right: 8px;">
                        Pill
                    </label>
                    <label style="display: block;">
                        <input type="radio" name="button_style" value="square" <?php checked($settings['button_style'] ?? 'circular', 'square'); ?> style="margin-right: 8px;">
                        Square
                    </label>
                </div>
                
                <!-- Position -->
                <h3>📍 Button Position</h3>
                <div style="margin-bottom: 20px;">
                    <select id="position" style="width: 100%; padding: 8px;">
                        <option value="bottom-center" <?php selected($settings['position'] ?? 'bottom-center', 'bottom-center'); ?>>Bottom Center</option>
                        <option value="bottom-left" <?php selected($settings['position'] ?? 'bottom-center', 'bottom-left'); ?>>Bottom Left</option>
                        <option value="bottom-right" <?php selected($settings['position'] ?? 'bottom-center', 'bottom-right'); ?>>Bottom Right</option>
                        <option value="top-center" <?php selected($settings['position'] ?? 'bottom-center', 'top-center'); ?>>Top Center</option>
                        <option value="top-left" <?php selected($settings['position'] ?? 'bottom-center', 'top-left'); ?>>Top Left</option>
                        <option value="top-right" <?php selected($settings['position'] ?? 'bottom-center', 'top-right'); ?>>Top Right</option>
                    </select>
                </div>
                
                <!-- Advanced Options -->
                <h3>⚡ Advanced</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="dark_mode" <?php checked($settings['dark_mode'] ?? false); ?> style="margin-right: 8px;">
                        Dark Mode
                    </label>
                    <label style="display: flex; align-items: center;">
                        <input type="checkbox" id="enable_debug" <?php checked($settings['enable_debug'] ?? false); ?> style="margin-right: 8px;">
                        Debug Mode
                    </label>
                </div>
                
                <!-- Save Button -->
                <div style="text-align: center; margin-top: 30px;">
                    <button type="submit" class="button-primary" style="padding: 12px 30px; font-size: 16px;">
                        💾 Save Settings
                    </button>
                </div>
                
            </form>
        </div>
        
        <!-- Right Panel: Instructions -->
        <div style="flex: 0 0 300px; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h2 style="margin-top: 0; color: #2271b1;">📖 Setup Guide</h2>
            
            <div style="margin-bottom: 20px;">
                <h4>🎯 Custom Fields</h4>
                <p style="font-size: 13px; margin-bottom: 15px;">Add these custom fields to your posts:</p>
                <ul style="font-size: 12px; line-height: 1.4;">
                    <li><code>trailer_url</code> - Video trailer link</li>
                    <li><code>review_score</code> - Rating (e.g. "4.5")</li>
                    <li><code>review_source</code> - Review site (e.g. "IGN")</li>
                    <li><code>game_price</code> - Price without $ (e.g. "59.99")</li>
                </ul>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h4>🔧 Troubleshooting</h4>
                <p style="font-size: 13px;">If not working:</p>
                <ol style="font-size: 12px; line-height: 1.4;">
                    <li>Enable plugin above</li>
                    <li>Go to a single post page</li>
                    <li>Check browser console (F12)</li>
                    <li>Look for red "DEMONTEK ACTIVE" box</li>
                </ol>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h4>📱 Mobile Layout</h4>
                <p style="font-size: 13px;">Mobile positioning (≤690px):</p>
                <ul style="font-size: 12px; line-height: 1.4;">
                    <li>Title: 220px from top</li>
                    <li>Content: 320px from top</li>
                    <li>Full-width with 15px margins</li>
                </ul>
            </div>
            
            <!-- Quick Actions -->
            <div style="display: grid; gap: 10px;">
                <button class="button" onclick="resetToDefaults()" style="width: 100%;">🔄 Reset to Defaults</button>
                <button class="button" onclick="applyGamingPreset()" style="width: 100%;">🎮 Gaming Preset</button>
                <button class="button" onclick="applyMinimalPreset()" style="width: 100%;">✨ Minimal Preset</button>
            </div>
        </div>
        
    </div>
    
    <!-- Status Messages -->
    <div id="demontek-messages" style="margin-top: 20px;"></div>
</div>

<style>
#demontek-admin input[type="checkbox"], #demontek-admin input[type="radio"] {
    transform: scale(1.1);
}
#demontek-admin h3 {
    color: #2271b1;
    border-bottom: 2px solid #f0f0f1;
    padding-bottom: 5px;
    margin-bottom: 15px;
}
#demontek-admin .button-primary {
    background: linear-gradient(45deg, #2271b1, #135e96) !important;
    border: none !important;
    text-shadow: none !important;
    box-shadow: 0 4px 15px rgba(34, 113, 177, 0.3) !important;
}
#demontek-admin .button-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 6px 20px rgba(34, 113, 177, 0.4) !important;
}
</style>