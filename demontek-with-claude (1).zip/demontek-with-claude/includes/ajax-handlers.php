jQuery(document).ready(function($) {
    
    // Form submission
    $('#demontek-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = {
            action: 'demontek_save_settings',
            nonce: '<?php echo wp_create_nonce('demontek_settings_nonce'); ?>',
            enabled: $('#demontek_enabled').is(':checked'),
            show_prev: $('#show_prev').is(':checked'),
            show_next: $('#show_next').is(':checked'),
            show_delete: $('#show_delete').is(':checked'),
            button_style: $('input[name="button_style"]:checked').val(),
            position: $('#position').val(),
            dark_mode: $('#dark_mode').is(':checked'),
            delete_redirect: 'smart',
            load_delay: 500,
            enable_debug: $('#enable_debug').is(':checked'),
            title_position: $('#title_position').val(),
            show_excerpt: $('#show_excerpt').is(':checked'),
            hide_original_title: $('#hide_original_title').is(':checked'),
            show_trailers: $('#show_trailers').is(':checked'),
            show_reviews: $('#show_reviews').is(':checked'),
            show_price: $('#show_price').is(':checked'),
            show_custom_field: $('#show_custom_field').is(':checked'),
            custom_field_name: $('#custom_field_name').val(),
            content_layout: $('#content_layout').val()
        };
        
        $.post(ajaxurl, formData, function(response) {
            if (response.success) {
                showMessage('✅ Settings saved successfully!', 'success');
            } else {
                showMessage('❌ Error saving settings: ' + response.data, 'error');
            }
        });
    });
    
    function showMessage(text, type) {
        var className = type === 'success' ? 'notice-success' : 'notice-error';
        var html = '<div class="notice ' + className + ' is-dismissible"><p>' + text + '</p></div>';
        $('#demontek-messages').html(html);
        setTimeout(function() {
            $('#demontek-messages').empty();
        }, 3000);
    }
});

// Global preset functions
function resetToDefaults() {
    jQuery('#demontek_enabled, #show_prev, #show_next, #show_delete, #show_excerpt').prop('checked', true);
    jQuery('#dark_mode, #enable_debug, #hide_original_title, #show_trailers, #show_reviews, #show_price, #show_custom_field').prop('checked', false);
    jQuery('input[name="button_style"][value="circular"]').prop('checked', true);
    jQuery('#position').val('bottom-center');
    jQuery('#title_position').val('top-left');
    jQuery('#content_layout').val('stacked');
    jQuery('#custom_field_name').val('');
    jQuery('input').trigger('change');
}

function applyGamingPreset() {
    jQuery('#dark_mode, #show_trailers, #show_reviews, #show_price').prop('checked', true);
    jQuery('input[name="button_style"][value="circular"]').prop('checked', true);
    jQuery('#position').val('bottom-center');
    jQuery('#title_position').val('bottom-left');
    jQuery('#content_layout').val('stacked');
    jQuery('#hide_original_title').prop('checked', true);
    jQuery('input').trigger('change');
}

function applyMinimalPreset() {
    jQuery('#dark_mode, #show_trailers, #show_reviews, #show_price, #show_custom_field').prop('checked', false);
    jQuery('input[name="button_style"][value="square"]').prop('checked', true);
    jQuery('#position').val('top-right');
    jQuery('#title_position').val('disabled');
    jQuery('#show_excerpt').prop('checked', false);
    jQuery('#content_layout').val('stacked');
    jQuery('input').trigger('change');
}